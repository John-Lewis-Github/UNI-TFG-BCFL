#!/bin/bash
cd ..
 docker build . -t chainapi/node-web-app