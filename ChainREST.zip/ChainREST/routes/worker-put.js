const { parentPort } = require("worker_threads");
const conf = require("./config.json");
const { initGatewayOptions, initGateway, queryChaincode } = require("./fabric-utils");

let contract;

parentPort.once("message", async (req) => {
  const gatewayOptions = await initGatewayOptions(conf);
  contract = await initGateway(conf, gatewayOptions);
  const body = JSON.parse(req).body;
  console.log(body)
  await queryChaincode(contract, "pushData", [body['id'], JSON.stringify(body)]);
  parentPort.postMessage({});
});
