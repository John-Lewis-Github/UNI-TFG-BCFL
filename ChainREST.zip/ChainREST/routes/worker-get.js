const { parentPort } = require("worker_threads");
const conf = require("./config.json");
const { initGatewayOptions, initGateway, queryChaincode } = require("./fabric-utils");

let contract;

parentPort.once("message", async (req) => {
  const { id } = JSON.parse(req).query || {}; // extraer el parámetro "id" y otros parámetros
  if (!id) {
    const errorMessage = "El parámetro de búsqueda 'id' no ha sido definido.";
    console.error(errorMessage);
    throw new Error(errorMessage);
  }
  console.log("El valor de 'id' es:", id);
  const gatewayOptions = await initGatewayOptions(conf);
  contract = await initGateway(conf, gatewayOptions);
  const queryResult = await queryChaincode(contract, "pullData", [id]); // pasar "id" como argumento en el query
  console.log("El tipo de objeto de queryResult es:", typeof queryResult); // Verificar el tipo de objeto de queryResult
  if (typeof queryResult === "string") {
    console.log("El contenido de queryResult es:", queryResult); // Imprimir el contenido de queryResult si es una cadena de texto
  }
  parentPort.postMessage(JSON.stringify(queryResult));
});

